# LeoSpark — Sticker After Dark

A responsive, single-file Gen Z sticker storefront demo.

## Features
- Dark emo / neon pink / purple / lime styling
- Responsive desktop and mobile layout
- Sticker categories and live search
- Demo bag interaction (not a real checkout)
- No external libraries or paid services required

## Publish free with GitHub Pages
1. Sign in to GitHub and create a **public** repository named `leospark-stickers`.
2. Choose **Add file → Upload files**.
3. Upload `index.html` from this folder and commit it to the `main` branch.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch `main` and folder `/(root)`, then save.
7. Wait a few minutes; the Pages section will show your website URL.

This is a demo storefront. The bag is not connected to payments or order processing. Replace the demo social links with your own. Do not put passwords, API keys, or access tokens in website code.
